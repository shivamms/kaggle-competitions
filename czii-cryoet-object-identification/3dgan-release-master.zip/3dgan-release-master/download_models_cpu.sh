mkdir -p models_cpu

wget http://3dgan.csail.mit.edu/models_cpu/car_G_cpu.t7 -O models_cpu/car_G_cpu.t7
wget http://3dgan.csail.mit.edu/models_cpu/chair_G_cpu.t7 -O models_cpu/chair_G_cpu.t7
wget http://3dgan.csail.mit.edu/models_cpu/desk_G_cpu.t7 -O models_cpu/desk_G_cpu.t7
wget http://3dgan.csail.mit.edu/models_cpu/gun_G_cpu.t7 -O models_cpu/gun_G_cpu.t7
wget http://3dgan.csail.mit.edu/models_cpu/sofa_G_cpu.t7 -O models_cpu/sofa_G_cpu.t7
