mkdir -p models_gpu

wget http://3dgan.csail.mit.edu/models_gpu/car_G_gpu.t7 -O models_gpu/car_G_gpu.t7
wget http://3dgan.csail.mit.edu/models_gpu/chair_G_gpu.t7 -O models_gpu/chair_G_gpu.t7
wget http://3dgan.csail.mit.edu/models_gpu/desk_G_gpu.t7 -O models_gpu/desk_G_gpu.t7
wget http://3dgan.csail.mit.edu/models_gpu/gun_G_gpu.t7 -O models_gpu/gun_G_gpu.t7
wget http://3dgan.csail.mit.edu/models_gpu/sofa_G_gpu.t7 -O models_gpu/sofa_G_gpu.t7
