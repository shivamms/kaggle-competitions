mkdir -p demo_inputs

wget http://3dgan.csail.mit.edu/demo_inputs/car.mat -O demo_inputs/car.mat
wget http://3dgan.csail.mit.edu/demo_inputs/chair.mat -O demo_inputs/chair.mat
wget http://3dgan.csail.mit.edu/demo_inputs/desk.mat -O demo_inputs/desk.mat
wget http://3dgan.csail.mit.edu/demo_inputs/gun.mat -O demo_inputs/gun.mat
wget http://3dgan.csail.mit.edu/demo_inputs/sofa.mat -O demo_inputs/sofa.mat
